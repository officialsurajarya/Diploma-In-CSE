<!doctype html>
 <html class="no-js" lang=""> 
    <html><head><title>SingUp</title>
<link rel="stylesheet" href="bootstrap.min.css">
  <link rel="stylesheet" href="bootstrap-theme.min.css">
<link rel="stylesheet" href="font-awesome.min.css">
<link rel="stylesheet" href="hover-min.css">
  <script src="jquery.js"></script>
  <script src="bootstrap.min.js"></script>
  
<script src="ind.js"></script></head>
<body style='font-family:Century Gothic;background-image:url(image/black.png);color:white; '>
        <div class='container'><ul class="nav nav-tabs" style='font-size:20px;'>
            <li><a href="index.html">Home</a></li>
          
          <li><a href="signup.php">SignUp</a></li>

                  </ul>
	<div class="row"><div class='col-md-3'></div><div class='col-md-8'>
<form action="cus_login.php" method='post'><h2 style="margin-left:150px;color:white">SignIn Customer </h2>
<span class="text-success" style="font-size:20px;">Email :</span></a>
<input class="form-control" type="email" name="t1" placeholder="mail@provider.com" required style="width:500px;"><br/>
<span class="text-success" style="font-size:20px;">Password :</span></a>
<input class="form-control" type="password" name="t2" placeholder="Password" required style="width:500px;"><br/>
<button type="submit" class="btn btn-primary" style="width:500px;">SignIn
</button><br/><br><a href="#"><i><span class="text-danger">Forget Password</i></span></a>*</form></div><div class='col-md-2'></div></div><hr/>
<div class="row"><div class='col-md-3'></div><div class='col-md-8'>
<form action="admin_login.php" method='post'><h2 style="margin-left:150px;color:white">SignIn Admin</h2>
<span class="text-success" style="font-size:20px;">Email :</span></a>
<input class="form-control" type="email" name="t1" placeholder="mail@provider.com" required style="width:500px;"><br/>
<span class="text-success" style="font-size:20px;">Password :</span></a>
<input class="form-control" type="password"name="t2" placeholder="Password" required style="width:500px;"><br/>
<button type="submit" class="btn btn-primary" style="width:500px;">SignIn
</button><br/><br><a href="#"><i><span class="text-danger">Forget Password</i></span></a>*</form></div><div class='col-md-2'></div></div></div>
</body></html>