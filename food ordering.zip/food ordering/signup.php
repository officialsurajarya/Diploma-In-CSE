<!doctype html>
 <html class="no-js" lang=""> 
    <html><head><title>SingUp</title>
<link rel="stylesheet" href="bootstrap.min.css">
  <link rel="stylesheet" href="bootstrap-theme.min.css">
<link rel="stylesheet" href="font-awesome.min.css">
<link rel="stylesheet" href="hover-min.css">
  <script src="jquery.js"></script>
  <script src="bootstrap.min.js"></script>
  
<script src="ind.js"></script></head>
<body style='font-family:Century Gothic;background-image: url(image/black.png);'><div class='container'><ul class="nav nav-tabs" style='font-size:20px;'>
            <li><a href="index.html">Home</a></li>
          
          <li><a href="login.php">SignIn</a></li>

                  </ul>
	<div class="row"><div class='col-md-3'></div><div class='col-md-8'>
<form action="cus_signup.php" method="post"><h2 style="margin-left:140px;color:white">Sign Up Customer </h2>
                
<span class="text-primary" style="font-size:20px;">Name :</span></a>
<input class="form-control" type="text" name="t1" placeholder="Your Name" required style="width:500px;"><br/>
<span class="text-primary" style="font-size:20px;">Email :</span></a>
<input class="form-control" type="email" name="t2" placeholder="mail@provider.com" required style="width:500px;"><br/>
<span class="text-primary" style="font-size:20px;">Address :</span></a>
<textarea class="form-control input-text text-area"rows="5" cols="4"placeholder="Your Address with landmark" name="t3"required style="width:500px;"/></textarea><br/>
 <span class="text-primary" style="font-size:20px;">Zip/Postal Code :</span></a>
<input class="form-control" type="number" placeholder="Your Pin code" name="t4" required style="width:500px;"><br/>

<span class="text-primary" style="font-size:20px;">Mobile :</span></a>
<input class="form-control" type="number" placeholder="9876543210" name="t5"required style="width:500px;"><br/>
<span class="text-primary" style="font-size:20px;">Password :</span></a>
<input class="form-control" type="password" placeholder="Password" name="t6" required style="width:500px;"><br/>
<span class="text-primary" required style="font-size:20px;">Confirm Password :</span></a>
<input class="form-control" type="password" placeholder="Confirm Password" name="t7"required style="width:500px;"><br/>

<button type="submit" class="btn btn-success" style="width:500px;">Sign Up </span>
</button></form></div><div class='col-md-2'></div></div></div>
</body></html>